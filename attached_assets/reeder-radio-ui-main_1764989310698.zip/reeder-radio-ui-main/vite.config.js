import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "livekit-client": "livekit-client/dist/livekit-client.esm.js",
    },
  },
  optimizeDeps: {
    include: ["livekit-client"],
  },
});
